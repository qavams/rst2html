import docutils.core
  
docutils.core.publish_file(
    source_path='C:\\Users\\QavamS\\Downloads\\Compressed\\rst\\example\\sec.rst',
    destination_path='C:\\Users\\QavamS\\Downloads\\Compressed\\rst\\example\\sec.html',
    writer_name ="html")
