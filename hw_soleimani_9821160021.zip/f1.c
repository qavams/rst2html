#include <stdio.h>
int main()
{
   /* printf function displays the content that is
    * passed between the double quotes.
    */
   printf("Hello World");
   return 0;
}