..  raw:: html
    :file: header.html

#. نمونه کد اصلی 

    .. include:: f2.c
        :code: c
        :number-lines:
        :class: ltr




#. نمونه کد متناسب 



    .. include:: f1.c
        :code: c
        :number-lines:
        :class: ltr





    .. code:: C

        return x;

    ::

      "ab12cd +34.34-45.1slkdfj4a5   33.3   3  5"
      12  34.34  45.1  4  5  33.3  3  5
      double* extns(const char*s);

`مطلب شماره بعد
<pos.html>`_

.. ::

    .. title: post2
